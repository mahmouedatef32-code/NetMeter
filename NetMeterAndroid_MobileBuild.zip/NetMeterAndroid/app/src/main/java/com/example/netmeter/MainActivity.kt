package com.example.netmeter

import android.app.Activity
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.app.AppOpsManager
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.net.ConnectivityManager
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.DecimalFormat
import java.util.Calendar

class MainActivity : Activity() {
    private lateinit var statsManager: NetworkStatsManager
    private lateinit var content: LinearLayout
    private lateinit var summaryText: TextView
    private lateinit var detailsText: TextView
    private val prefs by lazy { getSharedPreferences("netmeter", Context.MODE_PRIVATE) }
    private val df = DecimalFormat("#,##0.00")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        statsManager = getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager
        buildUi()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (::summaryText.isInitialized) refresh()
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow("android:get_usage_stats", Process.myUid(), packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 42, 36, 36)
            setBackgroundColor(0xFFF5F7FB.toInt())
        }
        scroll.addView(content)
        setContentView(scroll)

        addText("عداد الإنترنت", 27, true, 0xFF102A43.toInt())
        addText("متابعة استهلاك Wi‑Fi وبيانات الهاتف", 15, false, 0xFF52606D.toInt())
        addSpace(20)

        val permission = Button(this).apply {
            text = "تفعيل صلاحية إحصائيات الاستخدام"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        }
        content.addView(permission, matchWrap())

        addSpace(14)
        summaryText = addText("جارٍ قراءة الاستهلاك…", 18, true, 0xFF102A43.toInt())
        addSpace(12)
        detailsText = addText("", 15, false, 0xFF334E68.toInt())

        addSpace(20)
        val refresh = Button(this).apply {
            text = "تحديث الاستهلاك"
            setOnClickListener { refresh() }
        }
        content.addView(refresh, matchWrap())

        addSpace(12)
        val note = addText(
            "ملاحظة: يحتاج أندرويد إلى منح صلاحية «الوصول إلى إحصائيات الاستخدام» من الإعدادات. قد تختلف دقة بيانات شبكة الهاتف حسب إصدار أندرويد والشريحة ومشغل الخدمة. لا يستهلك التطبيق باقتك أثناء قراءة الإحصائيات.",
            13, false, 0xFF627D98.toInt()
        )
        note.setPadding(0, 12, 0, 0)
    }

    private fun addText(value: String, size: Int, bold: Boolean, color: Int): TextView {
        val v = TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            gravity = Gravity.RIGHT
            textDirection = View.TEXT_DIRECTION_RTL
        }
        content.addView(v, matchWrap())
        return v
    }

    private fun addSpace(h: Int) {
        content.addView(View(this), LinearLayout.LayoutParams(1, h))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun monthStart(): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.DAY_OF_MONTH, 1)
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }

    private data class Usage(val rx: Long, val tx: Long) {
        val total: Long get() = rx + tx
    }

    private fun deviceUsage(type: Int, start: Long, end: Long): Usage {
        return try {
            val bucket = statsManager.querySummaryForDevice(type, null, start, end)
            Usage(bucket.rxBytes, bucket.txBytes)
        } catch (_: Exception) {
            Usage(0, 0)
        }
    }

    private fun bytes(v: Long): String {
        val n = v.toDouble()
        return when {
            n >= 1024.0 * 1024 * 1024 -> "${df.format(n / (1024.0 * 1024 * 1024))} GB"
            n >= 1024.0 * 1024 -> "${df.format(n / (1024.0 * 1024))} MB"
            n >= 1024 -> "${df.format(n / 1024)} KB"
            else -> "$v B"
        }
    }

    private fun refresh() {
        if (!hasUsageAccess()) {
            summaryText.text = "الصلاحية غير مفعّلة"
            detailsText.text = "اضغط زر تفعيل الصلاحية بالأعلى، ثم اختر «عداد الإنترنت» وفعّل السماح بالوصول إلى إحصائيات الاستخدام، وبعدها ارجع للتطبيق واضغط تحديث."
            return
        }

        val start = monthStart()
        val end = System.currentTimeMillis()
        val wifi = deviceUsage(ConnectivityManager.TYPE_WIFI, start, end)
        val mobile = deviceUsage(ConnectivityManager.TYPE_MOBILE, start, end)
        val total = wifi.total + mobile.total

        summaryText.text = "استهلاك الشهر الحالي\n${bytes(total)}"
        detailsText.text = buildString {
            append("📶 Wi‑Fi\n")
            append("تحميل: ${bytes(wifi.rx)}\nرفع: ${bytes(wifi.tx)}\nالإجمالي: ${bytes(wifi.total)}\n\n")
            append("📱 بيانات الهاتف\n")
            append("تحميل: ${bytes(mobile.rx)}\nرفع: ${bytes(mobile.tx)}\nالإجمالي: ${bytes(mobile.total)}\n\n")
            append("آخر تحديث: ${java.text.SimpleDateFormat("yyyy/MM/dd  HH:mm", java.util.Locale.getDefault()).format(java.util.Date())}")
        }
    }
}
